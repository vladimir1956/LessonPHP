<?php

use App\Models\HasEmail;
use App\Models\User;

require __DIR__ .  '/../protected/autoload.php';

function sendMessage(HasEmail $user)
{
    echo 'Send to:' . $user->getEmail();
}

$user = new User();
$user->email = 'vova@gmail.com';

sendMessage($user);