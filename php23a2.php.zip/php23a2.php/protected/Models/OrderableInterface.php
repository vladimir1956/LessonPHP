<?php

namespace App\Models;

interface OrderableInterface
{
    public function getPrice();

}