<?php

namespace App\Models;

interfase HasEmail
    {
        public function getEmail();
    }