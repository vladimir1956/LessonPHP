<?php

class Product
{
	public $id;
	public $title;
	public $price;
	public $descrip;
	public $image;
}


?>