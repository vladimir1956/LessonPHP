<?php

require __DIR__ . '/../protected/Db.php';
require __DIR__ . '/../protected/Models/Product.php';

$db = new Db();
$data = $db->query('SELECT * FROM products', Product::class);

var_dump($data);

?>