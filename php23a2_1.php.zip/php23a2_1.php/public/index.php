<?php



require __DIR__ . '/autoload.php';

$data =  \App\Models\Product::findAll();

 $view = new \App\View();
 $view->assign('products', $data);

 //var_dump($view);die;
//require    __DIR__  . '/../templates/index.php';
$view->display(__DIR__ . '/../templates/index.php');

$view->display(__DIR__ . '/../templates/test.php');







