<?php

require __DIR__ . '/../protected/Db.php';
require __DIR__ . '/../protected/Models/Product.php';

$product = new Product();
$data = $product->findAll();

var_dump($data);

?>