<?php

class Product
{
	public $id;
	public $title;
	public $price;
	public $descrip;
	public $image;
	
	public function findAll()
	{
		$sql = 'SELECT * FROM products';
		$db = new Db();
		return $db->query($sql, 'Product');
	}
}


?>