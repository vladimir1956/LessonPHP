<?php

class Product
{
	protected static $table = 'users';
	
	public $id;
	public $email;
	public $password;
	
	
	public static function findAll()
	{
		//$sql = 'SELECT * FROM users';
		//$sql = 'SELECT * FROM' . Product::$table;
		$sql = 'SELECT * FROM' . self::$table;
		$db = new Db();
		return $db->query($sql, 'User');
	}
}


?>