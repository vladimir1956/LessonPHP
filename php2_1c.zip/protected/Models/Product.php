<?php

class Product
{
	protected static $table = 'products';
	
	public $id;
	public $title;
	public $price;
	public $descrip;
	public $image;
	
	public static function findAll()
	{
		//$sql = 'SELECT * FROM products';
		//$sql = 'SELECT * FROM' . Product::$table;
		$sql = 'SELECT * FROM' . self::$table;
		$db = new Db();
		return $db->query($sql, 'Product');
	}
}


?>