<?php

class Db
{
	protected $dbh;
	
	public function __construct()
	{
		$this->dbh = new \PDO('mysql:host=localhost;dbname=php2', 'root', '');
	}
	
	public function query($sql, $class)
	{
		$sth = $this->dbh->prepare($sql);
		$sth->execute();
		$data = $sth->fetchAll(PDO::FETCH_ASSOC);
		$ret =[];
		
		foreach ($data as $row){
			$obj = new $class;
			
			//var_dump($obj);die;
			// $row['id']  => $obj->id
			// $row['title']  => $obj->title
			
			foreach($row as $key => $val){
				$obj->$key = $val;
	/*обьект-> свойсто -> имя которого в переменной	*/		
	/*обратиться к свойству обьекта по его имени,
	а имя в меня в другой переменной.
	обращение к свойству по имени, но имя в другой переменной*/
			}
			// $key = 'id'
			// $obj->$key === $obj->id
			/*имя свойство содержится в переменной я хочу к свойству
			обратиться*/
			// $key = 'id';
			// $arr[$key];
			
			$ret[] = $obj;
		}
		return $ret;
	}
	
}


?>